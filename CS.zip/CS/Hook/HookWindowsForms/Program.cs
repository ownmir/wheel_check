﻿using System;
using System.Drawing;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HookWindowsForms
{
    static class Program
    {
        static void LoadPage(System.Diagnostics.Process pp, string brow)
        {
            try
            {
                pp.Start();
            }
            catch
            {
                string url;
                if (brow == "Chrome")
                    url = @"www.google.com/chrome/index.html";
                else
                    url = @"www.mozilla.org/";
                DialogResult result = MessageBox.Show("Not install browser " + brow + ". Go to page download (https://" + url + ") with Internet explorer? ", "", 
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    // System.Diagnostics.Process pIE = new System.Diagnostics.Process();
                    pp.StartInfo.FileName = @"IEXPLORE.EXE";
                    pp.StartInfo.Arguments = url;
                    try
                    {
                        pp.Start();
                        pp = null;
                    }
                    catch
                    { MessageBox.Show("Problem with Internet explorer"); }
                }
                    
            }
        }
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            var form = new Form1();
            using (NotifyIcon icon = new NotifyIcon())
            {
                icon.Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
                icon.Text = "Make screenshots cards";
                System.Diagnostics.Process p = new System.Diagnostics.Process();
                System.Diagnostics.Process pFirefox = new System.Diagnostics.Process();
                //Разрядность системы
                if (Environment.Is64BitOperatingSystem)
                {
                    string programFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
                    // p.StartInfo.FileName = programFiles + @"\Google\Chrome\Application\chrome.exe";
                    p.StartInfo.FileName = @"chrome.exe";
                    pFirefox.StartInfo.FileName = @"firefox.exe";
                }
                else
                {
                    string programFiles = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                    // p.StartInfo.FileName = programFiles + @"\Google\Chrome\Application\chrome.exe";
                    p.StartInfo.FileName = @"chrome.exe";
                    pFirefox.StartInfo.FileName = @"firefox.exe";
                }
                
                p.StartInfo.Arguments = @"https://fundaria.com";
                pFirefox.StartInfo.Arguments = @"https://fundaria.com";
                icon.ContextMenu = new ContextMenu(
                    new[]
                    {
                new MenuItem("Make screenshot (F7)", (s, e) => Form1.myfunc()),
                new MenuItem("To https://fundaria.com by Chrome", (s, e) => LoadPage(p, @"Chrome")),
                new MenuItem("To https://fundaria.com by Firefox", (s, e) => LoadPage(pFirefox, @"Firefox")),
                new MenuItem("Exit (F10)", (s, e) => Application.Exit()),
                    });
                icon.Visible = true;
                Hook.SetHook();
                Application.Run();
                Hook.UnHook();
                icon.Visible = false;
            }
            // Application.Run(new Form1());
        }
    }
}
