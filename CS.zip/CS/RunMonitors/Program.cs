﻿using System;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RunMonitors
{
    class Program
    {
        // Get a handle to an application window.
        [DllImport("USER32.DLL", CharSet = CharSet.Unicode)]
        public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        [DllImport("user32.dll", SetLastError = true)]
        internal static extern bool MoveWindow(IntPtr hWnd, int X, int Y, int nWidth, int nHeight, bool bRepaint);

        static void Main(string[] args)
        {
            System.Diagnostics.Process terr1 = new System.Diagnostics.Process();
            terr1.StartInfo.FileName = @"C:\Users\300012appsrv\Desktop\B2_AML_T1 терорист.lnk";
            try
            { terr1.Start(); }
            catch
            { Console.WriteLine("Помилка запуска ярлика терр1"); }

            System.Diagnostics.Process terr2 = new System.Diagnostics.Process();
            terr2.StartInfo.FileName = @"C:\Users\300012appsrv\Desktop\B2_AML_T5 черн OFAC.lnk";
            try
            { terr2.Start(); }
            catch
            { Console.WriteLine("Помилка запуска ярлика терр2"); }

            System.Diagnostics.Process terr3 = new System.Diagnostics.Process();
            terr3.StartInfo.FileName = @"C:\Users\300012appsrv\Desktop\b2_AML_T7 САМ_БАНК.lnk";
            try
            { terr3.Start(); }
            catch
            { Console.WriteLine("Помилка запуска ярлика терр3"); }
            System.Diagnostics.Process terr4 = new System.Diagnostics.Process();
            terr4.StartInfo.FileName = @"C:\Users\300012appsrv\Desktop\B2_AML_T8 неблаг.lnk";
            try
            { terr4.Start(); }
            catch
            { Console.WriteLine("Помилка запуска ярлика терр4"); }
            System.Diagnostics.Process terr5 = new System.Diagnostics.Process();
            terr5.StartInfo.FileName = @"C:\Users\300012appsrv\Desktop\B2_AML_T11 лиц с негативной репутацией.lnk";
            try
            { terr5.Start(); }
            catch
            { Console.WriteLine("Помилка запуска ярлика терр5"); }
            System.Diagnostics.Process terr6 = new System.Diagnostics.Process();
            //terr6.StartInfo.FileName = @"C:\Users\vladimir.fomin\Desktop\run_b2_tech1.cmd";
            terr6.StartInfo.FileName = @"C:\Users\300012appsrv\Desktop\b2_AML_T12 ПублічнОсоби.lnk";
            try
            {
                terr6.Start();
                //Console.ReadLine();
                //IntPtr terr6Handle = FindWindow("TProjectB2", "АБС Б2 [TECH1] Операционный день 20.03.2018 БД: B2_PROD /схема: CREATOR");
                
                //// Verify that terr6Handle is a running process.
                //if (terr6Handle == IntPtr.Zero)
                //{
                //    Console.WriteLine("terr6 is not running.");
                //    Console.ReadLine();
                //    // return;
                //}
                //MoveWindow(terr6Handle, 0, 0, 800, 600, true);
            }
            catch
            { Console.WriteLine("Помилка запуска ярлика терр6"); }
        }
    }
}
