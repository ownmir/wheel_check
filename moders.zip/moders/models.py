from django.conf import settings
from django.contrib.auth.models import AbstractUser
from django.db import models


class ExampleUserProfile(models.Model):
    user = models.ForeignKey(getattr(settings, 'AUTH_USER_MODEL', 'auth.User'), on_delete=models.CASCADE)
    description = models.TextField()
    url = models.URLField()

    def __str__(self):
        return "%s - %s" % (self.user, self.url)

    def get_absolute_url(self):
        return '/test/'


class CustomUser(AbstractUser):
    date_of_birth = models.DateField(blank=True, null=True)
    height = models.FloatField(blank=True, null=True)

    def get_full_name(self):
        return self.last_name + ' ' + self.username

    def get_short_name(self):
        return self.username

    def email_user(self, subject, message, from_email=None, **kwargs):
        pass

