from moderation import moderation
from moderation.moderator import GenericModerator

from moderationStudy.models import ExampleUserProfile


class UserProfileModerator(GenericModerator):
    notify_user = False
    auto_approve_for_staff = False


moderation.register(ExampleUserProfile, UserProfileModerator)
